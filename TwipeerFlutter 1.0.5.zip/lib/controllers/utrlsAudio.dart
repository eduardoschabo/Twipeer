extension FormatString on Duration {
  String format() => toString().substring(2, 7);
}
