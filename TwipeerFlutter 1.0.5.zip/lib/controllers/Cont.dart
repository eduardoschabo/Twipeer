import 'dart:convert';

import 'package:colibricmflutter/Utlit/TextUtil.dart';
import 'package:colibricmflutter/Widget/ASE.dart';

performEncryption() {
  final data1 = json.decode(decrypted);
  accounts = data1["account"];
}
