String path = 'assets/Svg/';

class images {
  //More Options HomeScreenPost
  static String Pin = path + 'Pin.svg';
  static String ShowLikes = path + 'Like.svg';
  static String BookMark = path + 'Bookmarkk.svg';
  static String block = path + 'Block.svg';
  static String Eyeslash = path + 'eyeslash.png';
  static String infocircle = path + 'Report.svg';
  static String reomve = path + 'Delete.svg';
  static String EdtiPost = path + 'Edite.svg';
}
