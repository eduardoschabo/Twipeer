/// Drawer last action enum
/// To detect last action from drawer if it was opened or closed.
enum DrawerLastAction { open, closed }
