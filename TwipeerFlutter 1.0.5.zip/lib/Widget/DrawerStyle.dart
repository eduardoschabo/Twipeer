enum DrawerStyle {
  defaultStyle,
  style1,
  style2,
  style3,
  style4,
}
